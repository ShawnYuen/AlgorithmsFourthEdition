see "main"
see book in page 44

java Rolls 1000000
Class Rolls simulates to cast a six-side dice n(10 or 1000000) times, and the result of each time is from 1 point to 6 points, also counts the number of its result of each side, then output the result