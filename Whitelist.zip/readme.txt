see "main"
see book in page 61-62

largeW is a white list, largeT is a total list contains white and black lists.
tinyW and tinyT are the same as the above.

data download: http://algs4.cs.princeton.edu/code/

note that I use "//" to comment on java file named StaticSETofInts from line48 to line 50, so that "check for duplicates"  doesn't work, because largeW and largeT contain so many duplicate values