see "main"
see book in page 51\
data download: http://algs4.cs.princeton.edu/code/

more in1.txt
more in2.txt
java Cat in1.txt in2 txt out.txt


Class Cat concatenate files
for example
file in1.txt is "This is" and file in2.txt is "a tinytest.", the result of performing concatenating two files is "This is a tinytest.", note that newline or enter in output file is created