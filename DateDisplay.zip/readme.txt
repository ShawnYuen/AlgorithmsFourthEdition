see "main"
see book in page 56

java DateDisplay 4 23 2016
java DateDisplay 04 23 2016