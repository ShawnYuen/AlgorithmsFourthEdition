see "main"
see book in page 139

java UF < tinyUF.txt
java UF < mediumUF.txt
java UF < largeUF.txt
Class UF finds connected components in input file, and outputs the number of those components

tinyUF		2 components
mediumUF	3 components
largeUF		6 components

data download: http://algs4.cs.princeton.edu/code/