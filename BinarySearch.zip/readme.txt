see "main"
see book in page 5

largeW is a white list, largeT is a total list contains white and black lists.
tinyW and tinyT are the same as the above.

data download: http://algs4.cs.princeton.edu/code/