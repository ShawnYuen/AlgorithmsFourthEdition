see "main"
see book in page 47

java Interval2D 0.2 0.5 0.5 0.6 100000
Class Interval2D simulates how to approximate the area of small rectangle in a unit square
First, create a small rectangle in a unit square
Second, cast n points(given by user) into the unit square, in fact, some points will fall into the small rectangle
Third, count how many points fall into the small rectangle

the first pair of values is the left-down point of the rectangle, for example,(0.2 0.5)
the second pair of values is the right-up point of the  rectangle, for example, (0.5 0.6)
the real area of the small rectangle is (0.6-0.5)*(0.5-0.2) / (1.0*1.0) = 0.03