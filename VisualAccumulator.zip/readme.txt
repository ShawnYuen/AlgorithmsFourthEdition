see "main"
see book in page 58-59

java TestVisualAccumulator 2000
Class TestVisualAccumulator computes the mean of generated values from left to right