see "main"
see book in page 111

java DoublingTest

information:
250	0.0
500	0.0
1000	0.1
2000	0.5
4000	4.2
8000	33.9
16000	266.7