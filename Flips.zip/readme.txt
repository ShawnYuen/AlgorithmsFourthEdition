see "main"
see book in page 42

java Flips 10
java Flips 1000000
Class Flips simulates to cast a coin n(10 or 1000000) times, and the result of each time is either head or tail, also counts the number of its result of head or tail, then the result of delta is the gap(#heads - #tails)