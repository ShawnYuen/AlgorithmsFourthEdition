see "main"
see book in page 22

java Random 5 100.0 200.0
you can get 5 random real number between 100.0 and 200.0