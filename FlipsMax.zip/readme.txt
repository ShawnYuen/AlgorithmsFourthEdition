see "main"
see book in page 43

java FlipsMax 1000000
Class FlipsMax simulates to cast a coin n(10 or 1000000) times, and the result of each time is either head or tail, also counts the number of its result of head or tail, then the result of FlipsMax is either heads wins or tails wins