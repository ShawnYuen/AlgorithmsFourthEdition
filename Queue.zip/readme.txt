see "main"
see book in page 94

more tobe.txt
java Queue < tobe.txt

data download: http://algs4.cs.princeton.edu/code/