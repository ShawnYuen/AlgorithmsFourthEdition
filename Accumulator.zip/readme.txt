see "main"
see book in page 57

java Accumulator < tinyT.txt
java Accumulator < tinyW.txt
Class Accumulator receives a file as its input, and then outputs four messages: the number of values, the mean/average of all values, the stddev of all values and the var of all values

java TestAccumulator 1000
java TestAccumulator 1000000
java TestAccumulator 1000000
What Class TestAccumulator is different to the above Class Accumulator, is that it receives a integer, which is the number of random numbers created by StdRandom.random(), and then Class TestAccumulator outputs the mean of all values