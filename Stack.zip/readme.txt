see "main"
see book in page 94

more tobe.txt
java Stack < tobe.txt

data download: http://algs4.cs.princeton.edu/code/