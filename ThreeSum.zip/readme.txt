see "main"
see book in page 109-110

java ThreeSum 1Kints.txt
java ThreeSum 2Kints.txt
java ThreeSum 4Kints.txt
java ThreeSum 8Kints.txt

information:
0.322 for 70
2.451 for 528
19.464 for 4039
157.199 for 32074

data download: http://algs4.cs.princeton.edu/code/